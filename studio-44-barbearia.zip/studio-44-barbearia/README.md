# Studio 44 — Barbearia Premium

Landing page profissional desenvolvida para a barbearia **Studio 44** em Birigui - SP.

## 🚀 Como rodar o projeto localmente

1. Extraia o conteúdo deste arquivo ZIP em uma pasta do seu computador.
2. Abra o terminal na pasta do projeto e instale as dependências:
   ```bash
   npm install
   ```
3. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
4. Acesse no seu navegador: `http://localhost:3000` (ou o endereço indicado no seu terminal).

---

## 📦 Build para Produção (Hospedagem)

Para gerar os arquivos finais otimizados para publicação (Vercel, Netlify, Cloudflare, etc.):
```bash
npm run build
```
Os arquivos prontos serão gerados na pasta `dist/`.

---

## 🛠️ Tecnologias Utilizadas
- **React 19** com **TypeScript**
- **Tailwind CSS v4** (tema e variáveis semânticas)
- **Vite 8** (bundler ultra veloz)
- **Lucide React** (ícones de interface)
- **Google Fonts** (Playfair Display para títulos & Raleway para o corpo)
- **Integração WhatsApp** com gerador de mensagem formatada para agendamentos
