import { ServiceItem, StatisticItem, GalleryItem } from '../types.ts';

export const BUSINESS_INFO = {
  name: 'Studio 44',
  tagline: 'Estilo & Tradição',
  slogan: 'A precisão do corte. O respeito ao homem.',
  niche: 'Barbearia Premium',
  address: 'Av. Youssef Ismail Mansour, 44 - Sl 7 - Patrimonio Silvares, Birigui - SP, 16202-484',
  city: 'Birigui - SP',
  phoneDisplay: '(18) 99636-5991',
  phoneSanitized: '5518996365991',
  whatsappUrl: 'https://wa.me/5518996365991?text=Ol%C3%A1%2C%20Studio%2044!%20Gostaria%20de%20agendar%20um%20hor%C3%A1rio.',
  googleMapsUrl: 'https://www.google.com/maps/search/?api=1&query=Av.+Youssef+Ismail+Mansour%2C+44+-+Sl+7+-+Patrimonio+Silvares%2C+Birigui+-+SP%2C+16202-484',
  hours: 'Terça a Sábado · 09h às 20h'
};

export const SERVICES: ServiceItem[] = [
  {
    id: 'corte-masculino',
    name: 'Corte Masculino',
    price: 60,
    duration: '45 min',
    tagline: 'Visagismo & Precisão',
    description: 'Diagnóstico de formato facial, corte na tesoura e máquina de alta precisão, finalização e alinhamento.',
    image: 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Consultoria de Visagismo', 'Lavagem refrescante', 'Finalização com pomada matte']
  },
  {
    id: 'barba',
    name: 'Barba Tradicional',
    price: 45,
    duration: '35 min',
    tagline: 'Navalha & Toalha Quente',
    description: 'Ritual clássico de barbear com aplicação de toalha quente, óleo pré-barba, lâmina esterilizada e hidratação.',
    image: 'https://images.unsplash.com/photo-1512690459411-b9245aed614b?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Vapor de ozônio e toalha quente', 'Navalhete descartável de precisão', 'Bálsamo pós-barba calmante']
  },
  {
    id: 'tratamento-capilar',
    name: 'Tratamento Capilar',
    price: 80,
    duration: '50 min',
    tagline: 'Nutrição & Terapia do Couro',
    description: 'Limpeza profunda, controle de oleosidade e fortalecimento dos fios com produtos botânicos selecionados.',
    image: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=1200&q=80',
    highlights: ['Detox e esfoliação suave', 'Massagem craniana estimulante', 'Ampola reconstrutora de nutrientes']
  }
];

export const STATS: StatisticItem[] = [
  {
    value: '15+',
    label: 'Anos de Tradição',
    description: 'Dedicação diária à arte do corte e hospitalidade masculina.'
  },
  {
    value: '10.000+',
    label: 'Clientes Atendidos',
    description: 'Homens que confiam sua assinatura visual às nossas mãos.'
  },
  {
    value: '5',
    label: 'Barbeiros Especialistas',
    description: 'Mestres com certificações nacionais e olhar criterioso.'
  },
  {
    value: '4.9',
    label: 'Avaliação Média',
    description: 'Excelência aprovada na precisão e pontualidade.'
  }
];

export const GALLERY: GalleryItem[] = [
  {
    title: 'Corte e Alinhamento',
    category: 'Precisão',
    image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=1200&q=80',
    span: 'col-span-1 md:col-span-2'
  },
  {
    title: 'Ritual de Navalha Quente',
    category: 'Tradição',
    image: 'https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&w=1000&q=80',
    span: 'col-span-1'
  },
  {
    title: 'Ambiente & Poltronas de Couro',
    category: 'Conforto',
    image: 'https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&w=1000&q=80',
    span: 'col-span-1'
  },
  {
    title: 'Estilo & Acabamento Manual',
    category: 'Identidade',
    image: 'https://images.unsplash.com/photo-1593702295094-ada7554100c3?auto=format&fit=crop&w=1200&q=80',
    span: 'col-span-1 md:col-span-2'
  }
];
