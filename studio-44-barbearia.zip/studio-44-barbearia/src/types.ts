export interface ServiceItem {
  id: string;
  name: string;
  price: number;
  duration: string;
  tagline: string;
  description: string;
  image: string;
  highlights: string[];
}

export interface StatisticItem {
  value: string;
  label: string;
  description: string;
}

export interface GalleryItem {
  title: string;
  category: string;
  image: string;
  span?: string;
}
