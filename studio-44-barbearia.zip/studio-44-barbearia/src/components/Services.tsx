import React from 'react';
import { ArrowUpRight, Check, Clock } from 'lucide-react';
import { SERVICES } from '../data/barbershop.ts';
import { ServiceItem } from '../types.ts';

interface ServicesProps {
  onSelectService: (service: ServiceItem) => void;
}

export const Services: React.FC<ServicesProps> = ({ onSelectService }) => {
  return (
    <section id="servicos" className="py-28 sm:py-36 px-6 sm:px-10 bg-[#090D16] relative">
      {/* Decorative background light */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-[#0F172A] rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header: Minimalist & Grand */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-6 border-b border-slate-800/80 pb-10">
          <div>
            <span className="text-[#D4AF37] text-xs uppercase tracking-[0.3em] font-semibold block mb-3">
              Menu de Cuidados
            </span>
            <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-white">
              Nossos Serviços
            </h2>
          </div>
          <p className="text-slate-400 text-sm sm:text-base font-light max-w-md leading-relaxed">
            Técnicas clássicas da barbearia artesanal com produtos de alto padrão e toalha aquecida.
          </p>
        </div>

        {/* 3 Distinct Luxury Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {SERVICES.map((service, index) => (
            <div
              key={service.id}
              className="group relative flex flex-col bg-[#0F172A] border border-slate-800/80 hover:border-[#D4AF37]/60 rounded-sm overflow-hidden transition-all duration-500 hover:shadow-2xl hover:shadow-[#D4AF37]/5 hover:-translate-y-1.5"
            >
              {/* Service Real Barber Image */}
              <div className="relative h-64 overflow-hidden bg-slate-900">
                <img
                  src={service.image}
                  alt={service.name}
                  className="w-full h-full object-cover object-center filter brightness-[0.88] contrast-[1.05] group-hover:scale-108 transition-transform duration-700 ease-out"
                  loading="lazy"
                />
                
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-[#0F172A]/40 to-transparent" />

                {/* Duration Tag */}
                <div className="absolute top-4 left-4 inline-flex items-center gap-1.5 px-3 py-1 bg-[#070B12]/80 backdrop-blur-md rounded-full border border-slate-700/60 text-[11px] text-slate-300 tracking-wider">
                  <Clock className="w-3 h-3 text-[#D4AF37]" />
                  <span>{service.duration}</span>
                </div>

                {/* Corner Number */}
                <div className="absolute top-4 right-4 text-xs font-serif text-[#D4AF37]/70 font-semibold tracking-widest">
                  0{index + 1}
                </div>
              </div>

              {/* Service Content */}
              <div className="p-8 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-baseline justify-between mb-2">
                    <span className="text-[11px] uppercase tracking-[0.2em] text-[#D4AF37] font-medium">
                      {service.tagline}
                    </span>
                    <div className="text-right">
                      <span className="text-2xl font-serif font-bold text-white tracking-tight">
                        R$ {service.price}
                      </span>
                    </div>
                  </div>

                  <h3 className="font-serif text-2xl font-semibold text-white mb-3 group-hover:text-[#D4AF37] transition-colors duration-300">
                    {service.name}
                  </h3>

                  <p className="text-slate-400 text-sm font-light leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Highlights list */}
                  <ul className="space-y-2.5 mb-8 border-t border-slate-800/80 pt-6">
                    {service.highlights.map((h, i) => (
                      <li key={i} className="flex items-center gap-2.5 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Direct Action Button */}
                <button
                  onClick={() => onSelectService(service)}
                  className="w-full py-3.5 px-4 bg-[#070B12] hover:bg-[#D4AF37] text-slate-200 hover:text-[#0F172A] border border-slate-700/80 hover:border-[#D4AF37] transition-all duration-300 font-semibold text-xs uppercase tracking-[0.2em] rounded-sm flex items-center justify-center gap-2 cursor-pointer group/btn"
                >
                  <span>Agendar Horário</span>
                  <ArrowUpRight className="w-4 h-4 text-[#D4AF37] group-hover/btn:text-[#0F172A] transition-colors duration-300" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
