import React from 'react';
import { Award, Star } from 'lucide-react';
import { STATS } from '../data/barbershop.ts';

export const About: React.FC = () => {
  return (
    <section id="sobre" className="py-28 sm:py-36 px-6 sm:px-10 bg-[#070B12] relative overflow-hidden border-t border-slate-900">
      
      {/* Ambient background glow */}
      <div className="absolute -bottom-24 right-0 w-[500px] h-[500px] bg-[#D4AF37]/5 blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Atmospheric Dual-Image Composition */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Primary Large Image */}
              <div className="relative rounded-sm overflow-hidden aspect-[3/4] border border-[#D4AF37]/20 shadow-2xl shadow-black">
                <img
                  src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&w=1000&q=80"
                  alt="Interior requintado e poltronas de couro do Studio 44"
                  className="w-full h-full object-cover object-center filter brightness-90 contrast-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#070B12]/80 via-transparent to-transparent" />
              </div>

              {/* Floating Overlap Card */}
              <div className="absolute -bottom-8 -right-4 sm:-right-8 p-6 bg-[#0F172A] border border-[#D4AF37]/40 rounded-sm shadow-2xl max-w-xs backdrop-blur-md">
                <div className="flex items-center gap-1.5 text-[#D4AF37] mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#D4AF37]" />
                  ))}
                </div>
                <p className="font-serif text-white font-semibold text-base mb-1">
                  Nota 4.9 em Birigui
                </p>
                <p className="text-slate-400 text-xs font-light">
                  Reconhecimento espontâneo de clientes que não abrem mão da pontualidade.
                </p>
              </div>

            </div>
          </div>

          {/* Right Column: Editorial Authority Copy & The 4 Specific Stats */}
          <div className="lg:col-span-7 flex flex-col justify-center pt-8 lg:pt-0">
            
            <div className="inline-flex items-center gap-2 text-[#D4AF37] text-xs font-semibold uppercase tracking-[0.3em] mb-4">
              <Award className="w-4 h-4" />
              <span>Sobre Nós · Tradição & Excelência</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-white mb-6 leading-tight">
              Mais que um corte. <br />
              <span className="italic font-light text-[#D4AF37]">Uma assinatura pessoal.</span>
            </h2>

            {/* Lean, high-impact copy without filler blocks */}
            <p className="text-slate-300 text-base sm:text-lg font-light leading-relaxed mb-12 max-w-2xl">
              No Studio 44, cada atendimento é conduzido com o tempo e o silêncio que o cavalheiro moderno merece. Respeitamos a sua rotina através de pontualidade impecável, visagismo sob medida e navalha quente.
            </p>

            {/* 4 Stats Grid in Gold & Slate (Strictly as specified in briefing) */}
            <div className="grid grid-cols-2 gap-6 sm:gap-8 pt-8 border-t border-slate-800">
              {STATS.map((stat, i) => (
                <div key={i} className="flex flex-col">
                  <span className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#D4AF37] tracking-tight mb-2">
                    {stat.value}
                  </span>
                  <span className="text-sm font-semibold text-white uppercase tracking-wider mb-1">
                    {stat.label}
                  </span>
                  <span className="text-xs text-slate-400 font-light leading-snug">
                    {stat.description}
                  </span>
                </div>
              ))}
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
