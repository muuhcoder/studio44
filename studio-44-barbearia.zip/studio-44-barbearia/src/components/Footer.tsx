import React from 'react';
import { ArrowUp, MapPin, Phone } from 'lucide-react';
import { BUSINESS_INFO } from '../data/barbershop.ts';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#05080E] text-slate-400 py-16 px-6 sm:px-10 border-t border-slate-900">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
        
        {/* Brand identity */}
        <div className="flex items-center gap-4 text-center md:text-left">
          <div className="w-10 h-10 rounded-full border border-[#D4AF37]/50 bg-[#0F172A] flex items-center justify-center text-[#D4AF37] font-serif font-bold text-lg">
            44
          </div>
          <div>
            <span className="font-serif text-lg font-bold tracking-widest text-white block">
              STUDIO 44
            </span>
            <span className="text-[10px] tracking-[0.25em] uppercase text-[#D4AF37]">
              Barbearia · Birigui / SP
            </span>
          </div>
        </div>

        {/* Address snippet */}
        <div className="text-center md:text-left text-xs text-slate-500 max-w-sm">
          <p className="text-slate-400 font-normal">{BUSINESS_INFO.address}</p>
          <p className="mt-1">Telefone: {BUSINESS_INFO.phoneDisplay}</p>
        </div>

        {/* Copyright, Download Zip & Scroll to top */}
        <div className="flex flex-wrap items-center gap-4 sm:gap-6 justify-center md:justify-end">
          <a
            href="/studio-44-barbearia.zip"
            download="studio-44-barbearia.zip"
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-sm bg-[#0F172A] border border-[#D4AF37]/40 hover:border-[#D4AF37] text-xs text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0F172A] transition-all duration-200"
            title="Baixar código fonte completo (.zip)"
          >
            <span>Baixar Projeto (.ZIP)</span>
          </a>
          <span className="text-xs text-slate-600">
            © {new Date().getFullYear()} Studio 44.
          </span>
          <button
            onClick={scrollToTop}
            aria-label="Voltar ao topo"
            className="w-10 h-10 rounded-sm bg-[#0F172A] border border-slate-800 hover:border-[#D4AF37] text-slate-400 hover:text-[#D4AF37] flex items-center justify-center transition-all duration-200 cursor-pointer"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

      </div>
    </footer>
  );
};
