import React from 'react';
import { ArrowDown, Calendar, ArrowRight, ShieldCheck } from 'lucide-react';
import { BUSINESS_INFO } from '../data/barbershop.ts';

interface HeroProps {
  onBookClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onBookClick }) => {
  return (
    <section
      id="inicio"
      className="relative min-h-screen flex flex-col justify-between pt-32 pb-16 px-6 sm:px-10 overflow-hidden bg-[#070B12]"
    >
      {/* Background Ambience Layers: Deep Slate #0F172A and Warm Gold Sheen */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-1/4 -right-40 w-[600px] h-[600px] rounded-full bg-[#D4AF37]/5 blur-[140px]" />
        <div className="absolute -bottom-20 -left-40 w-[500px] h-[500px] rounded-full bg-[#0F172A] blur-[120px]" />
        {/* Subtle grid accent */}
        <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#D4AF37_1px,transparent_1px)] [background-size:32px_32px]" />
      </div>

      {/* Main Hero Container */}
      <div className="relative z-10 max-w-7xl mx-auto w-full my-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
        
        {/* Left Column: Massive Editorial Typography & Action */}
        <div className="lg:col-span-7 flex flex-col items-start pr-0 lg:pr-8">
          
          {/* Subtle Tag / Heritage */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#D4AF37]/30 bg-[#0F172A]/80 backdrop-blur-sm mb-6 text-[#D4AF37] text-xs font-semibold tracking-[0.25em] uppercase">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Birigui · Desde 2009</span>
          </div>

          {/* Colossal Title with Responsive Clamp */}
          <h1 className="font-serif text-[clamp(2.75rem,7vw,6.25rem)] leading-[0.98] font-bold tracking-tight text-white mb-6">
            Estilo & <br />
            <span className="italic font-light text-[#D4AF37]">Tradição.</span>
          </h1>

          {/* Single Punchy Supporting Sentence (Máx 8-10 palavras, sem textão) */}
          <p className="text-slate-300 text-lg sm:text-xl font-light max-w-xl leading-relaxed mb-10 tracking-wide">
            {BUSINESS_INFO.slogan}
          </p>

          {/* Primary CTA and secondary touch */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
            <button
              onClick={onBookClick}
              className="px-8 py-4 bg-[#D4AF37] hover:bg-[#F7E7B4] text-[#0F172A] font-bold uppercase tracking-[0.2em] text-xs transition-all duration-300 shadow-xl shadow-[#D4AF37]/10 hover:shadow-[#D4AF37]/25 hover:translate-y-[-2px] flex items-center justify-center gap-3 cursor-pointer rounded-sm"
            >
              <Calendar className="w-4 h-4" />
              <span>Agende seu Horário</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <a
              href="#servicos"
              className="px-8 py-4 bg-[#0F172A] hover:bg-[#162035] text-slate-200 hover:text-[#D4AF37] border border-slate-700 hover:border-[#D4AF37]/40 uppercase tracking-[0.2em] text-xs transition-all duration-300 text-center rounded-sm"
            >
              Conhecer Serviços
            </a>
          </div>

          {/* Live reassurance badge */}
          <div className="mt-10 flex items-center gap-6 text-xs text-slate-400 tracking-wider">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Atendimento com hora marcada</span>
            </div>
            <span className="text-slate-700">|</span>
            <span className="text-[#D4AF37] font-serif italic text-sm">Nota 4.9 ★★★★★</span>
          </div>
        </div>

        {/* Right Column: Hero Visual - Single Grand, High-Fidelity Barber Image */}
        <div className="lg:col-span-5 relative w-full flex justify-center lg:justify-end">
          <div className="relative w-full max-w-[480px] aspect-[4/5] rounded-sm overflow-hidden p-2 bg-gradient-to-b from-[#D4AF37]/30 via-[#0F172A] to-transparent shadow-2xl shadow-black">
            
            <div className="relative w-full h-full overflow-hidden rounded-xs bg-[#0F172A]">
              <img
                src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=1200&q=85"
                alt="Barbeiro profissional do Studio 44 aparando barba com navalha em ambiente sofisticado"
                className="w-full h-full object-cover object-center filter brightness-[0.92] contrast-[1.08] hover:scale-105 transition-transform duration-1000 ease-out"
                loading="eager"
              />

              {/* Editorial Image Overlay Badge */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#070B12] via-transparent to-transparent opacity-80" />
              
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#0F172A]/90 backdrop-blur-md border border-[#D4AF37]/30 rounded-xs flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.25em] text-[#D4AF37]">Experiência Studio 44</p>
                  <p className="font-serif text-white text-sm font-semibold tracking-wide">Navalha, Toalha & Tradição</p>
                </div>
                <div className="w-8 h-8 rounded-full border border-[#D4AF37]/60 flex items-center justify-center text-[#D4AF37] font-serif text-xs">
                  44
                </div>
              </div>
            </div>

            {/* Corner metallic decorative borders */}
            <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-[#D4AF37]/70 pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-[#D4AF37]/70 pointer-events-none" />
          </div>
        </div>

      </div>

      {/* Bottom Subtle Scroll Peek Indicator */}
      <div className="relative z-10 w-full flex justify-between items-center max-w-7xl mx-auto pt-8 border-t border-slate-800/60 text-xs text-slate-500 tracking-widest uppercase">
        <span>Birigui · São Paulo</span>
        <a
          href="#servicos"
          className="flex items-center gap-2 hover:text-[#D4AF37] transition-colors duration-200 group"
          aria-label="Rolar para serviços"
        >
          <span>Explorar</span>
          <ArrowDown className="w-3.5 h-3.5 group-hover:translate-y-1 transition-transform duration-200 text-[#D4AF37]" />
        </a>
      </div>
    </section>
  );
};
