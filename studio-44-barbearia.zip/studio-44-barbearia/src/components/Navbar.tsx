import React, { useState, useEffect } from 'react';
import { Scissors, Menu, X, Phone, Calendar } from 'lucide-react';
import { BUSINESS_INFO } from '../data/barbershop.ts';

interface NavbarProps {
  onBookClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onBookClick }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Tradição', href: '#sobre' },
    { label: 'Galeria', href: '#galeria' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-[#070B12]/90 backdrop-blur-md py-4 border-b border-[#D4AF37]/20 shadow-2xl shadow-black/80'
          : 'bg-transparent py-7'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 flex items-center justify-between">
        {/* Brand / Monogram */}
        <a
          href="#inicio"
          className="group flex items-center gap-3 tracking-wider text-slate-100 focus:outline-none"
        >
          <div className="w-10 h-10 rounded-full border border-[#D4AF37] flex items-center justify-center bg-[#0F172A] group-hover:scale-105 group-hover:border-[#F7E7B4] transition-all duration-300 shadow-md shadow-black">
            <span className="font-serif text-[#D4AF37] text-lg font-bold tracking-tight">44</span>
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-xl sm:text-2xl font-bold tracking-[0.2em] text-white">
              STUDIO 44
            </span>
            <span className="text-[10px] tracking-[0.3em] uppercase text-[#D4AF37] font-sans -mt-1 font-medium">
              Barbearia
            </span>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium tracking-widest uppercase">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-slate-300 hover:text-[#D4AF37] transition-colors duration-200 py-1 relative group"
            >
              {link.label}
              <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-[#D4AF37] transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </nav>

        {/* Right CTA */}
        <div className="hidden lg:flex items-center gap-4">
          <a
            href={`tel:${BUSINESS_INFO.phoneSanitized}`}
            className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-400 hover:text-[#D4AF37] transition-colors duration-200"
          >
            <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>(18) 99636-5991</span>
          </a>

          <button
            onClick={onBookClick}
            className="relative px-6 py-2.5 bg-[#0F172A] hover:bg-[#D4AF37] text-[#D4AF37] hover:text-[#0F172A] border border-[#D4AF37] transition-all duration-300 text-xs font-semibold uppercase tracking-[0.2em] rounded-sm group overflow-hidden cursor-pointer"
          >
            <span className="relative z-10 flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5" />
              Agendar Horário
            </span>
          </button>
        </div>

        {/* Mobile Hamburger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-slate-200 hover:text-[#D4AF37] focus:outline-none cursor-pointer"
          aria-label="Abrir menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-x-0 top-[70px] bg-[#070B12]/95 backdrop-blur-xl border-b border-[#D4AF37]/20 p-8 flex flex-col gap-6 animate-in slide-in-from-top-4 duration-300 shadow-2xl">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="text-lg font-serif tracking-widest text-slate-200 hover:text-[#D4AF37] border-b border-slate-800 pb-3"
            >
              {link.label}
            </a>
          ))}

          <div className="pt-2 flex flex-col gap-4">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onBookClick();
              }}
              className="w-full py-3.5 bg-[#D4AF37] text-[#0F172A] font-bold text-xs uppercase tracking-[0.2em] rounded-sm text-center"
            >
              Agendar Horário
            </button>
            <a
              href={BUSINESS_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 border border-[#D4AF37]/50 text-[#D4AF37] font-semibold text-xs uppercase tracking-[0.2em] rounded-sm text-center flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4" />
              WhatsApp Direto
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
