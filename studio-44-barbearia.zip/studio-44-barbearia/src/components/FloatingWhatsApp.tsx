import React from 'react';
import { MessageCircle } from 'lucide-react';
import { BUSINESS_INFO } from '../data/barbershop.ts';

export const FloatingWhatsApp: React.FC = () => {
  return (
    <aside
      aria-label="Atendimento rápido via WhatsApp"
      className="fixed bottom-6 right-6 z-40"
    >
      <a
        href={BUSINESS_INFO.whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Fale conosco no WhatsApp do Studio 44"
        className="group relative flex items-center gap-3 px-4 py-3 bg-[#0F172A] hover:bg-[#D4AF37] border border-[#D4AF37]/60 hover:border-[#D4AF37] text-white hover:text-[#0F172A] rounded-full shadow-2xl transition-all duration-300 hover:scale-105"
      >
        {/* Pulsing indicator */}
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D4AF37] opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-[#D4AF37]" />
        </span>

        <MessageCircle className="w-5 h-5 text-[#D4AF37] group-hover:text-[#0F172A] transition-colors duration-300" />
        
        <span className="hidden sm:inline font-sans text-xs uppercase tracking-widest font-bold">
          Agendar no WhatsApp
        </span>
      </a>
    </aside>
  );
};
