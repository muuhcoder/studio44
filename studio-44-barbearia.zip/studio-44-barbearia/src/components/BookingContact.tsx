import React, { useState } from 'react';
import { MapPin, Phone, Clock, Calendar, CheckCircle, Send, Navigation } from 'lucide-react';
import { BUSINESS_INFO, SERVICES } from '../data/barbershop.ts';
import { ServiceItem } from '../types.ts';

interface BookingContactProps {
  selectedService: ServiceItem | null;
  onClearServiceSelection: () => void;
}

export const BookingContact: React.FC<BookingContactProps> = ({
  selectedService,
  onClearServiceSelection,
}) => {
  const [serviceId, setServiceId] = useState<string>(
    selectedService ? selectedService.id : 'corte-masculino'
  );
  const [clientName, setClientName] = useState('');
  const [clientDate, setClientDate] = useState('');
  const [clientTime, setClientTime] = useState('14:00');
  const [clientNotes, setClientNotes] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [validationError, setValidationError] = useState('');

  // Sync when selectedService prop changes
  React.useEffect(() => {
    if (selectedService) {
      setServiceId(selectedService.id);
    }
  }, [selectedService]);

  const activeService = SERVICES.find((s) => s.id === serviceId) || SERVICES[0];

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim()) {
      setValidationError('Por favor, informe seu nome para o agendamento.');
      return;
    }
    if (!clientDate) {
      setValidationError('Por favor, escolha uma data desejada.');
      return;
    }

    setValidationError('');
    setFormSubmitted(true);

    // Format formatted date (DD/MM/YYYY)
    const [year, month, day] = clientDate.split('-');
    const formattedDate = `${day}/${month}/${year}`;

    // Generate tailored WhatsApp message
    const message = encodeURIComponent(
      `Olá, Studio 44! Meu nome é *${clientName.trim()}*.\n` +
      `Gostaria de agendar o seguinte atendimento:\n\n` +
      `✂️ *Serviço:* ${activeService.name} (R$ ${activeService.price})\n` +
      `📅 *Data desejada:* ${formattedDate}\n` +
      `⏰ *Horário preferido:* ${clientTime}\n` +
      (clientNotes.trim() ? `💬 *Observação:* ${clientNotes.trim()}\n` : '') +
      `\nPoderia confirmar a disponibilidade na agenda? Obrigado!`
    );

    const waUrl = `https://wa.me/${BUSINESS_INFO.phoneSanitized}?text=${message}`;

    // Open WhatsApp in new tab
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-28 sm:py-36 px-6 sm:px-10 bg-[#070B12] relative overflow-hidden">
      
      {/* Subtle background glow */}
      <div className="absolute top-1/3 left-1/4 w-[600px] h-[600px] bg-[#D4AF37]/5 blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Headline */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <span className="text-[#D4AF37] text-xs uppercase tracking-[0.3em] font-semibold block mb-3">
            Agendamento & Localização
          </span>
          <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-white mb-4">
            Reserve seu Horário
          </h2>
          <p className="text-slate-400 text-sm sm:text-base font-light">
            Atendimento exclusivo com pontualidade britânica no coração de Birigui.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Essential Contact Information */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-10">
            <div>
              <h3 className="font-serif text-2xl text-white font-semibold mb-6">
                Studio 44 Barbearia
              </h3>
              
              <ul className="space-y-6 text-sm text-slate-300">
                {/* Address */}
                <li className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-sm bg-[#0F172A] border border-[#D4AF37]/30 flex items-center justify-center shrink-0 text-[#D4AF37]">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-1">
                      Endereço
                    </span>
                    <p className="leading-relaxed text-slate-200">
                      {BUSINESS_INFO.address}
                    </p>
                  </div>
                </li>

                {/* Phone & WhatsApp */}
                <li className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-sm bg-[#0F172A] border border-[#D4AF37]/30 flex items-center justify-center shrink-0 text-[#D4AF37]">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-1">
                      Telefone / WhatsApp
                    </span>
                    <p className="text-lg font-serif text-white tracking-wide">
                      {BUSINESS_INFO.phoneDisplay}
                    </p>
                    <span className="text-xs text-slate-400">Atendimento rápido via mensagem</span>
                  </div>
                </li>

                {/* Hours */}
                <li className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-sm bg-[#0F172A] border border-[#D4AF37]/30 flex items-center justify-center shrink-0 text-[#D4AF37]">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-1">
                      Horário de Funcionamento
                    </span>
                    <p className="text-slate-200">{BUSINESS_INFO.hours}</p>
                    <span className="text-xs text-emerald-400">Atendimento com hora marcada</span>
                  </div>
                </li>
              </ul>
            </div>

            {/* Direct Map Action Button */}
            <div className="p-6 rounded-sm bg-[#0F172A] border border-slate-800">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold">Localização Fácil</span>
                <span className="text-xs text-slate-400">Patrimonio Silvares</span>
              </div>
              <p className="text-xs text-slate-400 font-light mb-4">
                Próximo aos principais acessos da cidade, com facilidade de estacionamento.
              </p>
              <a
                href={BUSINESS_INFO.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-[#070B12] hover:bg-[#162035] text-[#D4AF37] border border-[#D4AF37]/40 font-semibold text-xs uppercase tracking-[0.2em] rounded-sm flex items-center justify-center gap-2 transition-all duration-300"
              >
                <Navigation className="w-4 h-4" />
                <span>Abrir no Google Maps</span>
              </a>
            </div>

          </div>

          {/* Right Column: Online Booking Card (Formulário Elegante com Redirecionamento ao WhatsApp) */}
          <div className="lg:col-span-7 bg-[#0F172A] border border-slate-800/90 rounded-sm p-8 sm:p-10 shadow-2xl relative">
            <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-800">
              <div>
                <span className="text-[11px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold">
                  Agendamento Online
                </span>
                <h4 className="font-serif text-2xl text-white font-semibold">
                  Selecione seus detalhes
                </h4>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-400 block">Total Previsto</span>
                <span className="font-serif text-2xl text-[#D4AF37] font-bold">
                  R$ {activeService.price}
                </span>
              </div>
            </div>

            {formSubmitted && (
              <div className="mb-6 p-4 rounded-sm bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 flex items-center gap-3 text-xs">
                <CheckCircle className="w-5 h-5 shrink-0" />
                <span>
                  Solicitação enviada ao WhatsApp! Nosso barbeiro confirmará o horário em instantes.
                </span>
              </div>
            )}

            {validationError && (
              <div className="mb-6 p-3 rounded-sm bg-rose-950/50 border border-rose-500/40 text-rose-300 text-xs">
                {validationError}
              </div>
            )}

            <form onSubmit={handleBookingSubmit} className="space-y-6">
              
              {/* Service Selection */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-slate-300 font-medium mb-2.5">
                  Serviço Desejado *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {SERVICES.map((srv) => (
                    <button
                      type="button"
                      key={srv.id}
                      onClick={() => setServiceId(srv.id)}
                      className={`p-3 text-left rounded-sm border transition-all duration-200 cursor-pointer ${
                        serviceId === srv.id
                          ? 'border-[#D4AF37] bg-[#D4AF37]/10 text-white shadow-sm'
                          : 'border-slate-800 bg-[#070B12] text-slate-400 hover:border-slate-700 hover:text-slate-200'
                      }`}
                    >
                      <div className="font-medium text-xs truncate">{srv.name}</div>
                      <div className="text-sm font-serif font-bold text-[#D4AF37] mt-1">
                        R$ {srv.price}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Client Name */}
              <div>
                <label
                  htmlFor="clientName"
                  className="block text-xs uppercase tracking-wider text-slate-300 font-medium mb-2"
                >
                  Seu Nome Completo *
                </label>
                <input
                  id="clientName"
                  type="text"
                  required
                  placeholder="Ex.: Lucas Andrade"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="w-full px-4 py-3 bg-[#070B12] border border-slate-800 focus:border-[#D4AF37] focus:outline-none text-white text-sm rounded-sm transition-colors duration-200"
                />
              </div>

              {/* Date and Time Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="clientDate"
                    className="block text-xs uppercase tracking-wider text-slate-300 font-medium mb-2"
                  >
                    Data Desejada *
                  </label>
                  <input
                    id="clientDate"
                    type="date"
                    required
                    value={clientDate}
                    onChange={(e) => setClientDate(e.target.value)}
                    className="w-full px-4 py-3 bg-[#070B12] border border-slate-800 focus:border-[#D4AF37] focus:outline-none text-white text-sm rounded-sm transition-colors duration-200 [color-scheme:dark]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="clientTime"
                    className="block text-xs uppercase tracking-wider text-slate-300 font-medium mb-2"
                  >
                    Horário Preferido *
                  </label>
                  <select
                    id="clientTime"
                    value={clientTime}
                    onChange={(e) => setClientTime(e.target.value)}
                    className="w-full px-4 py-3 bg-[#070B12] border border-slate-800 focus:border-[#D4AF37] focus:outline-none text-white text-sm rounded-sm transition-colors duration-200"
                  >
                    <option value="09:00">09:00 (Manhã)</option>
                    <option value="10:00">10:00 (Manhã)</option>
                    <option value="11:00">11:00 (Manhã)</option>
                    <option value="14:00">14:00 (Tarde)</option>
                    <option value="15:00">15:00 (Tarde)</option>
                    <option value="16:00">16:00 (Tarde)</option>
                    <option value="17:00">17:00 (Fim de tarde)</option>
                    <option value="18:00">18:00 (Noite)</option>
                    <option value="19:00">19:00 (Noite)</option>
                  </select>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label
                  htmlFor="clientNotes"
                  className="block text-xs uppercase tracking-wider text-slate-300 font-medium mb-2"
                >
                  Observações ou Preferência de Barbeiro (Opcional)
                </label>
                <input
                  id="clientNotes"
                  type="text"
                  placeholder="Ex.: Primeiro atendimento, prefiro corte clássico na tesoura"
                  value={clientNotes}
                  onChange={(e) => setClientNotes(e.target.value)}
                  className="w-full px-4 py-3 bg-[#070B12] border border-slate-800 focus:border-[#D4AF37] focus:outline-none text-white text-sm rounded-sm transition-colors duration-200"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-4 bg-[#D4AF37] hover:bg-[#F7E7B4] text-[#0F172A] font-bold uppercase tracking-[0.2em] text-xs transition-all duration-300 shadow-lg shadow-[#D4AF37]/20 flex items-center justify-center gap-3 cursor-pointer rounded-sm"
              >
                <Send className="w-4 h-4" />
                <span>Confirmar Agendamento via WhatsApp</span>
              </button>

              <p className="text-[11px] text-center text-slate-500">
                Ao clicar, você será direcionado ao nosso WhatsApp oficial para validação direta da vaga.
              </p>
            </form>

          </div>

        </div>

      </div>
    </section>
  );
};
