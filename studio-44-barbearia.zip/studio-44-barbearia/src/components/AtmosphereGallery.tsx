import React from 'react';
import { GALLERY } from '../data/barbershop.ts';
import { Sparkles } from 'lucide-react';

export const AtmosphereGallery: React.FC = () => {
  return (
    <section id="galeria" className="py-28 sm:py-36 px-6 sm:px-10 bg-[#090D16] relative border-t border-slate-900">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-[#D4AF37] text-xs font-semibold uppercase tracking-[0.3em] mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>A Atmosfera</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-white mb-4">
            Galeria & Detalhes
          </h2>
          <p className="text-slate-400 text-sm sm:text-base font-light">
            O ambiente projetado para sua pausa diária com café artesanal, navalha afiada e conforto.
          </p>
        </div>

        {/* Dynamic Mosaic Grid with Authentic Barbershop Photography */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {GALLERY.map((item, index) => (
            <div
              key={index}
              className={`group relative overflow-hidden rounded-sm bg-[#0F172A] border border-slate-800/80 hover:border-[#D4AF37]/50 transition-all duration-500 min-h-[320px] sm:min-h-[380px] ${
                item.span || 'col-span-1'
              }`}
            >
              <img
                src={item.image}
                alt={`Studio 44 - ${item.title}`}
                className="w-full h-full object-cover object-center filter brightness-[0.85] contrast-[1.05] group-hover:scale-105 group-hover:brightness-95 transition-all duration-700 ease-out"
                loading="lazy"
              />

              {/* Gradient Scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#070B12] via-transparent to-transparent opacity-90 group-hover:opacity-75 transition-opacity duration-300" />

              {/* Caption Card */}
              <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between pointer-events-none">
                <div>
                  <span className="text-[10px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block mb-1">
                    {item.category}
                  </span>
                  <h3 className="font-serif text-lg sm:text-xl font-medium text-white">
                    {item.title}
                  </h3>
                </div>
                <div className="w-8 h-8 rounded-full border border-white/20 bg-black/40 backdrop-blur-md flex items-center justify-center text-white/60 group-hover:border-[#D4AF37] group-hover:text-[#D4AF37] transition-colors duration-300">
                  +
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
