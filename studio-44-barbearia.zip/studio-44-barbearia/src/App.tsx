import React, { useState } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { Services } from './components/Services.tsx';
import { About } from './components/About.tsx';
import { AtmosphereGallery } from './components/AtmosphereGallery.tsx';
import { BookingContact } from './components/BookingContact.tsx';
import { Footer } from './components/Footer.tsx';
import { FloatingWhatsApp } from './components/FloatingWhatsApp.tsx';
import { ServiceItem } from './types.ts';

export default function App() {
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

  const scrollToBooking = (service?: ServiceItem) => {
    if (service) {
      setSelectedService(service);
    }
    const element = document.getElementById('contato');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#070B12] text-slate-100 flex flex-col font-sans selection:bg-[#D4AF37] selection:text-[#0F172A]">
      {/* Sleek Floating Header */}
      <Navbar onBookClick={() => scrollToBooking()} />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Hero: Editorial Fullscreen with Colossal Typography & Slogan */}
        <Hero onBookClick={() => scrollToBooking()} />

        {/* 2. Services: 3 Core Services with Prices & Direct Booking */}
        <Services onSelectService={(service) => scrollToBooking(service)} />

        {/* 3. About: Heritage, 15+ years, 10.000+ clients, 5 masters, 4.9 score */}
        <About />

        {/* 4. Gallery: Curated Barbershop Visuals & Rituals */}
        <AtmosphereGallery />

        {/* 5. Contact & Booking: Real Birigui Address, Phone & WhatsApp Form */}
        <BookingContact
          selectedService={selectedService}
          onClearServiceSelection={() => setSelectedService(null)}
        />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating Instant WhatsApp Button */}
      <FloatingWhatsApp />
    </div>
  );
}
